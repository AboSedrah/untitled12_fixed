// lib/main.dart
import 'dart:io' show Platform;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:flutter/services.dart';
 

// الخدمات
import 'services/prayer_times_service.dart';
import 'services/notification_service.dart';
import 'services/prayer_notification_service.dart';
import 'services/settings_service.dart';
import 'screens/settings/settings_screen.dart';
import 'services/settings_controller.dart';
import 'screens/stats/stats_screen.dart';
import 'services/quran_progress_service.dart';

// الشاشات الأساسية
import 'screens/home/home_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/signup_screen.dart';

// شاشة مواقيت الصلاة
import 'screens/prayer/prayer_times_screen.dart';
import 'screens/prayer/qibla_screen.dart';
import 'screens/hajj/hajj_umrah_screen.dart';
import 'screens/quran/quran_surah_list_screen.dart';
import 'screens/quran/tanzil_webview_screen.dart';
import 'screens/quran/quran_stats_screen.dart';

// شاشات مؤجلة التحميل
import 'screens/azkar/azkar_menu.dart' deferred as azkar_menu;
import 'screens/azkar/quran_duas_screen.dart' deferred as quran_duas;
import 'screens/calendar/calendar_home.dart' deferred as calendar_home;

// شاشات الأذكار الموجودة عندك
import 'screens/azkar/zikr_sabah.dart';
import 'screens/azkar/zikr_masaa.dart';
import 'screens/azkar/zikr_noum.dart';

// مفتاح ملاحة عام
final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();
 

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // وضع ملء الشاشة اللاصق لإخفاء الأشرطة أثناء القراءة
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  await Firebase.initializeApp();
  await initializeDateFormatting('ar');

  // تهيئة المناطق الزمنية والإشعارات + ربط navigatorKey
  await PrayerNotificationService.initTimeZone();
  final notif = NotificationService();
  await notif.init();
  notif.attachNavigatorKey(appNavigatorKey);

  // نشغّل التطبيق
  runApp(FazkoronyApp(notificationService: notif));

  // جدولة إشعارات الأذكار والصلاة (إنتاجي)
  await notif.scheduleDailyNotifications();
  final prayerNotif = PrayerNotificationService(notif.notificationsPlugin);
  await prayerNotif.schedulePrayerNotifications();

  // تكبيرات (إنتاجي)
  await notif.maybePlayTakbeerAtStartOfDhulHijjah();
  await prayerNotif.scheduleTakbeerAfterPrayersDuringDhulHijjah();

  // ملاحظات الاختبار:
  // يمكنك أيضًا تجربة دوال الاختبار من شاشة "لوحة اختبار الإشعارات".

  // ربط إعدادات التطبيق بإعادة الجدولة التلقائية
  _bindSettingsController(notif);
}

 

class FazkoronyApp extends StatelessWidget {
  const FazkoronyApp({super.key, required this.notificationService});

  final NotificationService notificationService;

  @override
  Widget build(BuildContext context) {
    // نوفّر PrayerTimesService و NotificationService و SettingsService عبر Provider
    return MultiProvider(
      providers: [
        Provider<PrayerTimesService>(
          create: (_) => PrayerTimesService()..initialize(),
        ),
        Provider<NotificationService>.value(value: notificationService),
        ChangeNotifierProvider(create: (_) => SettingsService()..load()),
        ChangeNotifierProvider(create: (_) => QuranProgressService()),
      ],
      child: Consumer<SettingsService>(
        builder: (context, s, _) => MaterialApp(
        navigatorKey: appNavigatorKey,
        debugShowCheckedModeBanner: false,
        title: 'فاذكروني',
          theme: ThemeData(
            fontFamily: s.fontFamily,
            colorScheme: ColorScheme.fromSwatch(
              primarySwatch: _primaryFromToken(s.primaryToken),
              brightness: Brightness.light,
            ),
            appBarTheme: AppBarTheme(
              backgroundColor: ColorScheme.fromSwatch(
                primarySwatch: _primaryFromToken(s.primaryToken),
                brightness: Brightness.light,
              ).primary,
              foregroundColor: Colors.white,
            ),
            useMaterial3: true,
          ),
          darkTheme: ThemeData(
            fontFamily: s.fontFamily,
            colorScheme: ColorScheme.fromSwatch(
              primarySwatch: _primaryFromToken(s.primaryToken),
              brightness: Brightness.dark,
            ),
            appBarTheme: AppBarTheme(
              backgroundColor: ColorScheme.fromSwatch(
                primarySwatch: _primaryFromToken(s.primaryToken),
                brightness: Brightness.dark,
              ).primary,
            ),
            useMaterial3: true,
          ),
          themeMode: s.themeMode,
          locale: s.locale,
          builder: (context, child) {
            final clamped = s.fontScale.clamp(0.9, 1.2);
            final mq = MediaQuery.of(context);
            return MediaQuery(
              data: mq.copyWith(textScaler: TextScaler.linear(clamped as double)),
              child: child ?? const SizedBox.shrink(),
            );
          },
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
          initialRoute: '/login',
        routes: {
          '/': (context) => const HomeScreen(),
          '/login': (context) => const LoginScreen(),
          '/signup': (context) => const SignUpScreen(),
          '/zikr_sabah': (context) => ZikrSabahScreen(),
          '/zikr_masa': (context) => EveningAzkarScreen(),
          '/zikr_noum': (context) => ZikrNoumScreen(),
          '/prayer_times': (context) {
            final args = ModalRoute.of(context)?.settings.arguments
            as Map<String, dynamic>?;
            return PrayerTimesScreen(highlight: args?['highlight'] as String?);
          },
            '/qibla': (context) => QiblaScreen(),
            '/hajj': (context) => HajjUmrahScreen(),
            '/quran': (context) => const QuranSurahListScreen(),
            '/quran_stats': (context) => const QuranStatsScreen(),
            // فتح Tanzil مباشرة عند الحاجة: استخدم Navigator.push(MaterialPageRoute(...)) من شاشة القائمة
            '/settings': (context) => const SettingsScreen(),
            '/stats': (context) => const StatsScreen(),
        },
        onGenerateRoute: (settings) {
          switch (settings.name) {
            case '/azkar':
              return MaterialPageRoute(
                builder: (_) => FutureBuilder(
                  future: azkar_menu.loadLibrary(),
                  builder: (c, s) => s.connectionState != ConnectionState.done
                      ? const Scaffold(
                      body:
                      Center(child: CircularProgressIndicator()))
                      : azkar_menu.AzkarCategoryScreen(),
                ),
              );
            case '/quran_duas':
              return MaterialPageRoute(
                builder: (_) => FutureBuilder(
                  future: quran_duas.loadLibrary(),
                  builder: (c, s) => s.connectionState != ConnectionState.done
                      ? const Scaffold(
                      body:
                      Center(child: CircularProgressIndicator()))
                      : quran_duas.QuranDuasScreen(),
                ),
              );
            case '/calendar':
              return MaterialPageRoute(
                builder: (_) => FutureBuilder(
                  future: calendar_home.loadLibrary(),
                  builder: (c, s) => s.connectionState != ConnectionState.done
                      ? const Scaffold(
                      body:
                      Center(child: CircularProgressIndicator()))
                      : calendar_home.CalendarHome(),
                ),
              );
          }
          return null;
        },
        ),
      ),
    );
  }
}

MaterialColor _primaryFromToken(String token) {
  switch (token) {
    case 'red':
      return Colors.red;
    case 'teal':
      return Colors.teal;
    case 'blue':
      return Colors.blue;
    case 'purple':
      return Colors.purple;
    case 'green':
      return Colors.green;
    case 'orange':
      return Colors.orange;
    case 'indigo':
    default:
      return Colors.indigo;
  }
}

void _bindSettingsController(NotificationService notif) async {
  // انتظر حتى تُنشأ الشجرة وتتوفر الـ context
  for (int i = 0; i < 10; i++) {
    final ctx = appNavigatorKey.currentContext;
    if (ctx != null) {
      try {
        final settings = Provider.of<SettingsService>(ctx, listen: false);
        SettingsController().bind(
          settings: settings,
          notifications: notif,
          plugin: notif.notificationsPlugin,
        );
        break;
      } catch (_) {}
    }
    await Future.delayed(const Duration(milliseconds: 200));
  }
}
