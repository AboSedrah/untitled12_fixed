import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../services/stats_controller.dart';
import '../../services/goals_controller.dart';
import '../../services/badges_controller.dart';
import '../../services/settings_service.dart';
import 'package:provider/provider.dart';
import '../../services/quran_progress_service.dart';
import '../quran/tanzil_webview_screen.dart';

class StatsScreen extends StatefulWidget {
  const StatsScreen({super.key});
  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  Map<String, dynamic>? _rollup;
  int _currentStreak = 0;
  int _longestStreak = 0;
  List<Map<String, dynamic>> _weekly = const [];
  List<Map<String, dynamic>> _monthly = const [];
  bool _heatmap = false;
  Map<String, double> _goalsProgress = const {};
  Set<String> _earnedBadges = const {};
  bool _unlocked = false;
  final TextEditingController _pinCtrl = TextEditingController();
  // Azkar browsing state
  int _aYear = DateTime.now().year;
  int _aMonth = DateTime.now().month;
  DateTime? _aEarliestDate;
  List<Map<String, dynamic>> _aDailyMonth = const [];

  // Quran stats
  int _qYear = DateTime.now().year;
  List<Map<String, int>> _qMonthly = const [];
  Map<String, int> _qYearSum = const {'actual': 0, 'target': 0, 'daysDone': 0, 'daysTotal': 0};
  List<Map<String, int>> _qWeekly = const [];
  int _qDailyActual = 0;
  int _qDailyTarget = 0;
  int _qMonthlyActual = 0;
  int _qMonthlyTarget = 0;
  int _qMonth = DateTime.now().month;
  List<Map<String, dynamic>> _qDailyMonth = const [];
  DateTime? _qEarliestDate;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await StatsController().ensureTodayInitialized();
    final roll = await StatsController().recomputeMonthlyRollup(DateTime.now());
    final p = await SharedPreferences.getInstance();
    final current = p.getInt('dhikr.streak.current') ?? 0;
    final longest = p.getInt('dhikr.streak.longest') ?? 0;
    final weekly = await StatsController().getWeeklySeries();
    final monthly = await StatsController().getMonthlySeries();
    final goals = await GoalsController().getActiveGoals();
    final gr = await GoalsController().evaluateAfterRead(
      currentStreak: current,
      monthlyRegularDays: (roll['regularDays'] as int?) ?? 0,
      monthlyTotal: (roll['totalDays'] as int?) ?? 30,
    );
    final earned = await BadgesController().getEarned();

    await _loadQuranStats();
    await _loadAzkarMonth();

    if (!mounted) return;
    setState(() {
      _rollup = roll;
      _currentStreak = current;
      _longestStreak = longest;
      _weekly = weekly;
      _monthly = monthly;
      _goalsProgress = gr.progress;
      _earnedBadges = earned;
    });
  }

  Future<void> _loadAzkarMonth() async {
    final earliest = await StatsController().firstDhikrDate();
    final daily = await StatsController().dailyTotalsForMonth(_aYear, _aMonth);
    if (!mounted) return;
    setState(() {
      _aEarliestDate = earliest;
      _aDailyMonth = daily;
    });
  }

  Future<void> _loadQuranStats() async {
    final svc = context.read<QuranProgressService>();
    final settings = context.read<SettingsService>();
    // Ensure today exists
    await svc.startDayIfNeeded(settings.quranDailyJuzCount);
    final today = svc.today;
    final qWeekly = await svc.weeklyBreakdown();
    final qMonthly = await svc.monthlyTotalsForYear(_qYear);
    final qYearSum = await svc.yearSummary(_qYear);
    final qDailyMonth = await svc.dailyTotalsForMonth(_qYear, _qMonth);
    final earliest = await svc.firstProgressDate();

    // Current month snapshot
    final now = DateTime.now();
    final curMonth = now.month;
    final cur = qMonthly.firstWhere(
      (m) => m['month'] == curMonth,
      orElse: () => {'month': curMonth, 'actual': 0, 'target': 0, 'daysDone': 0, 'daysTotal': 0},
    );

    if (!mounted) return;
    setState(() {
      _qWeekly = qWeekly;
      _qMonthly = qMonthly;
      _qYearSum = qYearSum;
      _qDailyTarget = today?.targetJuzCount ?? settings.quranDailyJuzCount;
      _qDailyActual = today?.actualCount ?? 0;
      _qMonthlyActual = cur['actual'] ?? 0;
      _qMonthlyTarget = cur['target'] ?? 0;
      _qDailyMonth = qDailyMonth;
      _qEarliestDate = earliest;
    });
  }

  Future<void> _loadQuranDailyForMonth() async {
    final svc = context.read<QuranProgressService>();
    final daily = await svc.dailyTotalsForMonth(_qYear, _qMonth);
    if (!mounted) return;
    setState(() {
      _qDailyMonth = daily;
    });
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsService>();
    return Scaffold(
      appBar: AppBar(title: const Text('الإحصاءات')),
      body: _rollup == null
          ? const Center(child: CircularProgressIndicator())
          : (settings.statsPinEnabled && !_unlocked)
              ? SafeArea(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const ListTile(
                                leading: Icon(Icons.lock),
                                title: Text('هذه الصفحة مقفلة'),
                                subtitle: Text('أدخل رمز PIN لفتحها'),
                              ),
                              TextField(
                                controller: _pinCtrl,
                                keyboardType: TextInputType.number,
                                obscureText: true,
                                decoration: const InputDecoration(hintText: 'PIN'),
                              ),
                              const SizedBox(height: 12),
                              ElevatedButton(
                                onPressed: () {
                                  if (settings.statsPinCode != null && settings.statsPinCode == _pinCtrl.text) {
                                    setState(() => _unlocked = true);
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرمز غير صحيح')));
                                  }
                                },
                                child: const Text('فتح'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                )
              : SafeArea(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // Azkar section header
                  Center(
                    child: Text(
                      'قسم الأذكار',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 12),
                  // KPIs
                  Row(
                    children: [
                      Expanded(child: _kpi('الأيام المنتظمة', '${_rollup!['regularDays']}/${_rollup!['totalDays']}')),
                      const SizedBox(width: 8),
                      Expanded(child: _kpi('نسبة الانتظام', '${((_rollup!['percentage'] as double).clamp(0.0, 100.0) as double).toStringAsFixed(0)}%')),
                      const SizedBox(width: 8),
                      Expanded(child: _kpi('أطول سلسلة', '$_longestStreak')),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // Calendar
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Text('تقويم الأذكار'),
                              const Spacer(),
                              IconButton(
                                onPressed: () {
                                  final prev = DateTime(_aYear, _aMonth, 1).subtract(const Duration(days: 1));
                                  if (_aEarliestDate != null && DateTime(prev.year, prev.month, 1).isBefore(DateTime(_aEarliestDate!.year, _aEarliestDate!.month, 1))) {
                                    return;
                                  }
                                  setState(() {
                                    _aYear = prev.year;
                                    _aMonth = prev.month;
                                  });
                                  _loadAzkarMonth();
                                },
                                icon: const Icon(Icons.chevron_right),
                                tooltip: 'السابق',
                              ),
                              Text('${_monthName(_aMonth)} ${_aYear}'),
                              IconButton(
                                onPressed: () {
                                  final next = DateTime(_aYear, _aMonth + 1, 1);
                                  final now = DateTime.now();
                                  if (DateTime(next.year, next.month, 1).isAfter(DateTime(now.year, now.month, 1))) {
                                    return;
                                  }
                                  setState(() {
                                    _aYear = next.year;
                                    _aMonth = next.month;
                                  });
                                  _loadAzkarMonth();
                                },
                                icon: const Icon(Icons.chevron_left),
                                tooltip: 'التالي',
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _azkarMonthCalendar(_heatmap),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Removed weekly and monthly charts per request
                  const SizedBox(height: 16),
                  // Goals progress
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('الأهداف'),
                          const SizedBox(height: 8),
                          for (final e in _goalsProgress.entries)
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 4),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(e.key),
                                  const SizedBox(height: 4),
                                  LinearProgressIndicator(value: e.value.clamp(0.0, 1.0)),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Removed badges grid per request
                  const SizedBox(height: 24),
                  // Quran section header
                  Center(
                    child: Text(
                      'قسم القرآن',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _quranSection(),
                ],
              ),
            ),
    );
  }

  Widget _quranSection() {
    final s = context.watch<SettingsService>();
    final int daysInSelectedMonth = DateTime(_qYear, _qMonth + 1, 0).day;
    final int daysInSelectedYear = DateTime(_qYear, 12, 31).difference(DateTime(_qYear, 1, 1)).inDays + 1;
    final int computedMonthlyTargetJuz = s.quranDailyJuzCount * daysInSelectedMonth;
    final int computedYearlyTargetJuz = s.quranDailyJuzCount * daysInSelectedYear;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text('إحصاءات القرآن') ,
                const Spacer(),
                const Text('سنة:'),
                const SizedBox(width: 8),
                DropdownButton<int>(
                  value: _qYear,
                  items: [for (int y = DateTime.now().year; y >= DateTime.now().year - 4; y--) DropdownMenuItem(value: y, child: Text('$y'))],
                  onChanged: (v) async {
                    if (v == null) return;
                    setState(() { _qYear = v; });
                    await _loadQuranStats();
                  },
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: _continueReading,
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('تابع القراءة'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _kpiTarget('هدف اليوم', s.quranDailyJuzCount)),
                const SizedBox(width: 8),
                Expanded(child: _kpiTargetKhatma('هدف الشهر', computedMonthlyTargetJuz)),
                const SizedBox(width: 8),
                Expanded(child: _kpiTargetKhatma('هدف السنة', computedYearlyTargetJuz)),
              ],
            ),
            const SizedBox(height: 12),
            // Weekly breakdown
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('التقسيم الأسبوعي (آخر 7 أيام)'),
                const SizedBox(height: 8),
                _qWeeklyChart(_qWeekly),
              ],
            ),
            const SizedBox(height: 12),
            // Current month daily breakdown (in khatmas)
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text('الشهر الحالي (بالختمات)'),
                    const Spacer(),
                    IconButton(
                      onPressed: () {
                        // Prev month respecting earliest date
                        final prev = DateTime(_qYear, _qMonth, 1).subtract(const Duration(days: 1));
                        if (_qEarliestDate != null && DateTime(prev.year, prev.month, 1).isBefore(DateTime(_qEarliestDate!.year, _qEarliestDate!.month, 1))) {
                          return;
                        }
                        setState(() {
                          _qYear = prev.year;
                          _qMonth = prev.month;
                        });
                        _loadQuranDailyForMonth();
                      },
                      icon: const Icon(Icons.chevron_right),
                      tooltip: 'السابق',
                    ),
                    Text('${_monthName(_qMonth)} ${_qYear}'),
                    IconButton(
                      onPressed: () {
                        // Next month up to current month
                        final next = DateTime(_qYear, _qMonth + 1, 1);
                        final now = DateTime.now();
                        if (DateTime(next.year, next.month, 1).isAfter(DateTime(now.year, now.month, 1))) {
                          return;
                        }
                        setState(() {
                          _qYear = next.year;
                          _qMonth = next.month;
                        });
                        _loadQuranDailyForMonth();
                      },
                      icon: const Icon(Icons.chevron_left),
                      tooltip: 'التالي',
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                _qMonthCalendar(_qDailyMonth),
              ],
            ),
            const SizedBox(height: 12),
            // Removed monthly khatma breakdown per request
          ],
        ),
      ),
    );
  }

  Widget _qWeeklyChart(List<Map<String, int>> series) {
    final maxTarget = series.fold<int>(1, (a, b) => (b['target'] ?? 0) > a ? (b['target'] ?? 0) : a);
    final now = DateTime.now();
    return SizedBox(
      height: 130,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (int i = 0; i < series.length; i++) ...[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Stack(
                    alignment: Alignment.bottomCenter,
                    children: [
                      Container(height: 90, width: 10, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(4))),
                      // target (neutral)
                      Container(height: 90 * ((series[i]['target'] ?? 0) / (maxTarget == 0 ? 1 : maxTarget)), width: 10, decoration: BoxDecoration(color: Colors.blueGrey.shade200, borderRadius: BorderRadius.circular(4))),
                      // actual (green if met, red if not)
                      Container(
                        height: 90 * ((series[i]['actual'] ?? 0) / (maxTarget == 0 ? 1 : maxTarget)),
                        width: 10,
                        decoration: BoxDecoration(
                          color: (series[i]['actual'] ?? 0) >= (series[i]['target'] ?? 0) ? Colors.green : Colors.red,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(_weekdayNameAr(now.subtract(Duration(days: series.length - 1 - i))), style: const TextStyle(fontSize: 10))
                ],
              ),
            ),
          ]
        ],
      ),
    );
  }

  Widget _qMonthlyChart(List<Map<String, int>> series) {
    final sorted = [...series]..sort((a, b) => (a['month'] ?? 1).compareTo(b['month'] ?? 1));
    final maxVal = (sorted
            .map((e) {
              final t = (e['target'] ?? 0) / 30.0;
              final a = (e['actual'] ?? 0) / 30.0;
              return t > 0 ? t : a;
            })
            .fold<double>(0, (a, b) => a > b ? a : b))
        .clamp(1, 999999)
        .toDouble();
    return Column(
      children: [
        for (final m in sorted) ...[
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(width: 70, child: Text(_monthName(m['month'] ?? 1))),
                const SizedBox(width: 8),
                Expanded(
                  child: Stack(
                    alignment: Alignment.centerLeft,
                    children: [
                      Container(
                        height: 16,
                        decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(8)),
                      ),
                      // target (neutral)
                      FractionallySizedBox(
                        widthFactor: (((m['target'] ?? 0) / 30.0) / maxVal).clamp(0.0, 1.0),
                        child: Container(
                          height: 16,
                          decoration: BoxDecoration(color: Colors.blueGrey.shade200, borderRadius: BorderRadius.circular(8)),
                        ),
                      ),
                      // actual (green if met, red if not)
                      FractionallySizedBox(
                        widthFactor: (((m['actual'] ?? 0) / 30.0) / maxVal).clamp(0.0, 1.0),
                        child: Container(
                          height: 16,
                          decoration: BoxDecoration(
                            color: ((m['actual'] ?? 0) / 30.0) >= ((m['target'] ?? 0) / 30.0) ? Colors.green : Colors.red,
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text('${_formatKhatmas(m['actual'] ?? 0)}/${_formatKhatmas(m['target'] ?? 0)} ختمة'),
              ],
            ),
          ),
        ]
      ],
    );
  }

  Widget _qDailyMonthChart(List<Map<String, int>> series) {
    if (series.isEmpty) return const SizedBox.shrink();
    final maxVal = (series
            .map((e) {
              final t = (e['target'] ?? 0) / 30.0;
              final a = (e['actual'] ?? 0) / 30.0;
              return t > 0 ? t : a;
            })
            .fold<double>(0, (a, b) => a > b ? a : b))
        .clamp(1, 999999)
        .toDouble();
    return SizedBox(
      height: 130,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (final e in series) ...[
            Expanded(
              child: Tooltip(
                message: 'اليوم ${e['day']}: ${_formatKhatmas(e['actual'] ?? 0)}/${_formatKhatmas(e['target'] ?? 0)} ختمة',
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    Container(height: 100, width: 12, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(4))),
                    Container(height: 100 * (((e['target'] ?? 0) / 30.0) / maxVal).clamp(0.0, 1.0), width: 12, decoration: BoxDecoration(color: Colors.blueGrey.shade200, borderRadius: BorderRadius.circular(4))),
                    Container(height: 100 * (((e['actual'] ?? 0) / 30.0) / maxVal).clamp(0.0, 1.0), width: 12, decoration: BoxDecoration(color: ((e['actual'] ?? 0) >= (e['target'] ?? 0)) ? Colors.green : Colors.red, borderRadius: BorderRadius.circular(4))),
                  ],
                ),
              ),
            )
          ]
        ],
      ),
    );
  }

  Widget _qMonthCalendar(List<Map<String, dynamic>> series) {
    final first = DateTime(_qYear, _qMonth, 1);
    final last = DateTime(_qYear, _qMonth + 1, 0);
    final daysInMonth = last.day;
    final startOffset = first.weekday % 7; // Sunday=7 -> 0, Monday=1 -> 1
    final today = DateTime.now();
    final dailyTargetFromSettings = context.watch<SettingsService>().quranDailyJuzCount;
    final List<Map<String, dynamic>> byDay = List.generate(daysInMonth, (i) {
      final idx = series.indexWhere((e) => (e['day'] ?? -1) == (i + 1));
      if (idx == -1) return {'day': i + 1, 'actual': 0, 'target': 0};
      return series[idx];
    });

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Weekday headers
        Row(
          children: [
            for (final h in _weekdayHeadersAr())
              Expanded(
                child: Center(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(h, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ),
                ),
              )
          ],
        ),
        const SizedBox(height: 6),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 7,
            mainAxisSpacing: 4,
            crossAxisSpacing: 4,
            childAspectRatio: 1.05,
          ),
          itemCount: startOffset + daysInMonth,
          itemBuilder: (context, index) {
            if (index < startOffset) {
              return const SizedBox.shrink();
            }
            final dayIndex = index - startOffset;
            final rec = byDay[dayIndex];
            final actual = (rec['actual'] ?? 0);
            // اعرض المقرر حسب الإعدادات الحالية بدلاً من لقطة اليوم المخزنة
            final target = dailyTargetFromSettings;
            final status = (rec['status'] as String?) ?? 'pending';
            final kh = actual / 30.0;
            final bg = _khHeatColor(kh);
            final isToday = (_qYear == today.year && _qMonth == today.month && (dayIndex + 1) == today.day);
            return Tooltip(
              message: 'اليوم ${dayIndex + 1}\nالمقرر: ${target} جزء\nالمقروء: ${actual} جزء\nالحالة: ${_statusLabel(status)}',
              child: InkWell(
                onTap: () {
                  final d = DateTime(_qYear, _qMonth, dayIndex + 1);
                  _showQuranDayDetails(d, actual, target, status);
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: bg,
                    borderRadius: BorderRadius.circular(8),
                    border: isToday ? Border.all(color: Colors.amber, width: 2) : null,
                  ),
                  padding: const EdgeInsets.all(4),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: Text('${dayIndex + 1}', style: TextStyle(fontSize: 10, color: kh > 0 ? Colors.white : Colors.black87)),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(
                              '${_formatKhatmas(actual)} خ',
                              style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: kh > 0 ? Colors.white : Colors.black87),
                            ),
                          ),
                          _qDayStatusIcon(actual: actual, target: target, size: 22),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _kpi(String title, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        child: Column(
          children: [
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(title, style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _kpiTarget(String title, int target) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        child: Column(
          children: [
            Text('$target', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(title, style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _kpiTargetKhatma(String title, int targetJuz) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        child: Column(
          children: [
            Text(_formatKhatmas(targetJuz), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(title, style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _kpiGoal(String title, int actual, int target) {
    final met = actual >= target && target > 0;
    final Color tone = met ? Colors.green : Colors.red;
    final Color bg = met ? Colors.green.shade50 : Colors.red.shade50;
    return Card(
      color: bg,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        child: Column(
          children: [
            Text('$actual/$target', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: tone)),
            const SizedBox(height: 4),
            Text(title, style: TextStyle(color: tone)),
          ],
        ),
      ),
    );
  }

  Widget _monthGrid(bool heatmap) {
    final now = DateTime.now();
    final first = DateTime(now.year, now.month, 1);
    final last = DateTime(now.year, now.month + 1, 0);
    final daysInMonth = last.day;
    final startOffset = first.weekday % 7;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            for (final h in _weekdayHeadersAr())
              Expanded(child: Center(child: Text(h, style: const TextStyle(fontSize: 12, color: Colors.grey))))
          ],
        ),
        const SizedBox(height: 6),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, mainAxisSpacing: 4, crossAxisSpacing: 4),
          itemCount: startOffset + daysInMonth,
          itemBuilder: (context, index) {
            if (index < startOffset) return const SizedBox.shrink();
            final i = index - startOffset;
            final d = first.add(Duration(days: i));
            final keyBase = 'dhikr.stats.${_yyyyMMdd(d)}';
            return FutureBuilder(
              future: SharedPreferences.getInstance(),
              builder: (context, snap) {
                if (!snap.hasData) return const SizedBox.shrink();
                final p = snap.data as SharedPreferences;
                final status = p.getString('$keyBase.status') ?? 'missed';
                final count = p.getInt('$keyBase.count') ?? 0;
                final color = heatmap
                    ? _heatColor(count)
                    : (status == 'regular' ? Colors.green.withOpacity(.8) : Colors.grey.shade300);
                return InkWell(
                  onTap: () => _showDayDetails(d, count, status),
                  child: Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(6)),
                    child: Text('${i + 1}', style: TextStyle(color: status == 'regular' ? Colors.white : Colors.black87)),
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }

  Widget _azkarMonthCalendar(bool heatmap) {
    final first = DateTime(_aYear, _aMonth, 1);
    final last = DateTime(_aYear, _aMonth + 1, 0);
    final daysInMonth = last.day;
    final startOffset = first.weekday % 7;
    final today = DateTime.now();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            for (final h in _weekdayHeadersAr())
              Expanded(
                child: Center(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(h, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ),
                ),
              )
          ],
        ),
        const SizedBox(height: 6),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 7,
            mainAxisSpacing: 4,
            crossAxisSpacing: 4,
            childAspectRatio: 1.05,
          ),
          itemCount: startOffset + daysInMonth,
          itemBuilder: (context, index) {
            if (index < startOffset) return const SizedBox.shrink();
            final i = index - startOffset;
            final d = first.add(Duration(days: i));
            final base = 'dhikr.stats.${_yyyyMMdd(d)}';
            return FutureBuilder(
              future: SharedPreferences.getInstance(),
              builder: (context, snap) {
                if (!snap.hasData) return const SizedBox.shrink();
                final p = snap.data as SharedPreferences;
                final status = p.getString('$base.status') ?? 'missed';
                final count = p.getInt('$base.count') ?? 0;
                final color = heatmap
                    ? _heatColor(count)
                    : (status == 'regular' ? Colors.green.withOpacity(.8) : Colors.grey.shade300);
                final isToday = (_aYear == today.year && _aMonth == today.month && (i + 1) == today.day);
                return InkWell(
                  onTap: () => _showDayDetails(d, count, status),
                  child: Container(
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(8),
                      border: isToday ? Border.all(color: Colors.amber, width: 2) : null,
                    ),
                    padding: const EdgeInsets.all(4),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Align(
                          alignment: Alignment.topRight,
                          child: Text('${i + 1}', style: TextStyle(fontSize: 10, color: status == 'regular' ? Colors.white : Colors.black87)),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            _azkarDayStatusIcon(status: status, count: count, size: 22),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }

  Widget _azkarDayStatusIcon({required String status, required int count, double size = 22}) {
    if (status == 'regular' || count > 0) {
      // اعتبر أي قراءات علامة إنجاز
      return Icon(Icons.check_circle, size: size, color: Colors.greenAccent);
    }
    return Icon(Icons.cancel_rounded, size: size, color: Colors.redAccent);
  }

  Color _heatColor(int count) {
    if (count == 0) return Colors.grey.shade300;
    if (count < 3) return Colors.lightGreen.shade200;
    if (count < 6) return Colors.green.shade400;
    return Colors.green.shade700;
  }

  String _statusLabel(String s) {
    switch (s) {
      case 'done':
        return 'منجز';
      case 'partial':
        return 'جزئي';
      case 'pending':
      default:
        return 'قيد الانتظار';
    }
  }

  void _showQuranDayDetails(DateTime d, int actualJuz, int targetJuz, String status) {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('تفاصيل ${_yyyyMMdd(d)}', style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('المقرر اليومي: ${targetJuz} جزء'),
              Text('المقروء: ${actualJuz} جزء'),
              Text('النسبة: ${targetJuz == 0 ? 0 : ((actualJuz * 100.0 / targetJuz).clamp(0.0, 100.0)).toStringAsFixed(0)}%'),
              Text('الحالة: ${_statusLabel(status)}'),
            ],
          ),
        ),
      ),
    );
  }

  void _showDayDetails(DateTime d, int count, String status) async {
    final cats = await StatsController().readCategoriesFor(d);
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('تفاصيل ${_yyyyMMdd(d)}', style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('الحالة: $status'),
              Text('المجموع: $count'),
              const Divider(),
              Text('الصباح: ${cats['sabah']}'),
              Text('المساء: ${cats['masa']}'),
              Text('النوم: ${cats['noum']}'),
              Text('بعد الصلوات: ${cats['prayers']}'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _chartCard(String title, List<Map<String, dynamic>> series) {
    final maxVal = (series.map((e) => (e['count'] as int)).fold<int>(0, (a, b) => a > b ? a : b)).clamp(1, 9999);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title),
          const SizedBox(height: 8),
          SizedBox(
            height: 120,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final e in series) ...[
                  Expanded(
                    child: Tooltip(
                      message: '${e['date']}: ${e['count']}',
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        height: 8 + 100 * ((e['count'] as int) / maxVal),
                        decoration: BoxDecoration(
                          color: Colors.indigo,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                  ),
                ]
              ],
            ),
          )
        ]),
      ),
    );
  }

  String _monthName(int m) => const [
    'يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'
  ][(m - 1).clamp(0, 11)];

  String _weekdayNameAr(DateTime d) {
    switch (d.weekday) {
      case DateTime.sunday: return 'الأحد';
      case DateTime.monday: return 'الاثنين';
      case DateTime.tuesday: return 'الثلاثاء';
      case DateTime.wednesday: return 'الأربعاء';
      case DateTime.thursday: return 'الخميس';
      case DateTime.friday: return 'الجمعة';
      case DateTime.saturday: return 'السبت';
      default: return '';
    }
  }

  String _yyyyMMdd(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _formatKhatmas(num juz) {
    final kh = juz / 30.0;
    if ((kh - kh.roundToDouble()).abs() < 1e-6) {
      return kh.toInt().toString();
    }
    return kh.toStringAsFixed(1);
  }

  List<String> _weekdayHeadersAr() => const ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

  Color _khHeatColor(double kh) {
    if (kh <= 0) return Colors.grey.shade300;
    if (kh < 0.5) return Colors.lightGreen.shade200;
    if (kh < 1.0) return Colors.green.shade400;
    return Colors.green.shade700;
  }

  Widget _qDayStatusIcon({required int actual, required int target, double size = 12}) {
    IconData icon;
    Color color;
    if (actual >= target && target > 0) {
      icon = Icons.check_circle;
      color = Colors.greenAccent;
    } else if (actual > 0 && actual < target) {
      icon = Icons.priority_high_rounded;
      color = Colors.amberAccent;
    } else {
      icon = Icons.cancel_rounded;
      color = Colors.redAccent;
    }
    return Icon(icon, size: size, color: color);
  }

  Future<void> _continueReading() async {
    final svc = context.read<QuranProgressService>();
    final pos = await svc.lastPosition();
    final s = pos?['surah'] ?? 1;
    final a = pos?['ayah'] ?? 1;
    if (!mounted) return;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => TanzilWebViewScreen(initialSurah: s, initialAyah: a),
    ));
  }
}


