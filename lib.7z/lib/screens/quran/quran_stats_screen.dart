import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/quran_progress_service.dart';
import 'tanzil_webview_screen.dart';

class QuranStatsScreen extends StatefulWidget {
  const QuranStatsScreen({super.key});

  @override
  State<QuranStatsScreen> createState() => _QuranStatsScreenState();
}

class _QuranStatsScreenState extends State<QuranStatsScreen> {
  int _year = DateTime.now().year;
  List<Map<String, int>> _monthly = const [];
  Map<String, int> _yearSum = const {'actual': 0, 'target': 0, 'daysDone': 0, 'daysTotal': 0};
  int _currentStreak = 0;
  int _longestStreak = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final svc = context.read<QuranProgressService>();
    final monthly = await svc.monthlyTotalsForYear(_year);
    final yearSum = await svc.yearSummary(_year);
    final current = await svc.currentStreak();
    final longest = await svc.longestStreak();
    if (!mounted) return;
    setState(() {
      _monthly = monthly;
      _yearSum = yearSum;
      _currentStreak = current;
      _longestStreak = longest;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إحصاءات القرآن')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      const Text('السنة:'),
                      const SizedBox(width: 8),
                      DropdownButton<int>(
                        value: _year,
                        items: [for (int y = DateTime.now().year; y >= DateTime.now().year - 4; y--) DropdownMenuItem(value: y, child: Text('$y'))],
                        onChanged: (v) {
                          if (v == null) return;
                          setState(() { _year = v; _loading = true; });
                          _load();
                        },
                      ),
                      const Spacer(),
                      ElevatedButton.icon(
                        onPressed: _continueReading,
                        icon: const Icon(Icons.play_arrow),
                        label: const Text('تابع القراءة'),
                      )
                    ],
                  ),
                  const SizedBox(height: 12),
                  // KPIs
                  Row(
                    children: [
                      Expanded(child: _kpi('إجمالي المقروء', '${_yearSum['actual']} جزء')),
                      const SizedBox(width: 8),
                      Expanded(child: _kpi('الهدف السنوي', '${_yearSum['target']} جزء')),
                      const SizedBox(width: 8),
                      Expanded(child: _kpi('نسبة الإنجاز', _percent(_yearSum['actual']!, _yearSum['target']!))),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: _kpi('أيام مكتملة', '${_yearSum['daysDone']}/${_yearSum['daysTotal']}')),
                      const SizedBox(width: 8),
                      Expanded(child: _kpi('السلسلة الحالية', '$_currentStreak')),
                      const SizedBox(width: 8),
                      Expanded(child: _kpi('أطول سلسلة', '$_longestStreak')),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('التقسيم الشهري'),
                          const SizedBox(height: 8),
                          _monthlyChart(_monthly),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _kpi(String title, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        child: Column(
          children: [
            Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(title, style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  String _percent(int a, int t) {
    if (t == 0) return '0%';
    final p = (a / t * 100).clamp(0, 100).toStringAsFixed(0);
    return '$p%';
  }

  Widget _monthlyChart(List<Map<String, int>> series) {
    final maxVal = (series.map((e) => (e['target']! > 0 ? e['target']! : e['actual']!)).fold<int>(0, (a, b) => a > b ? a : b)).clamp(1, 999999);
    return Column(
      children: [
        for (final m in series) ...[
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(width: 28, child: Text(_monthName(m['month']!))),
                const SizedBox(width: 8),
                Expanded(
                  child: Stack(
                    alignment: Alignment.centerLeft,
                    children: [
                      Container(
                        height: 16,
                        decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(8)),
                      ),
                      FractionallySizedBox(
                        widthFactor: (m['target']! / maxVal).clamp(0, 1).toDouble(),
                        child: Container(
                          height: 16,
                          decoration: BoxDecoration(color: Colors.indigo.shade200, borderRadius: BorderRadius.circular(8)),
                        ),
                      ),
                      FractionallySizedBox(
                        widthFactor: (m['actual']! / maxVal).clamp(0, 1).toDouble(),
                        child: Container(
                          height: 16,
                          decoration: BoxDecoration(color: Colors.indigo, borderRadius: BorderRadius.circular(8)),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text('${m['actual']}/${m['target']}'),
              ],
            ),
          ),
        ]
      ],
    );
  }

  String _monthName(int m) {
    const names = ['ينا', 'فبر', 'مار', 'أبر', 'ماي', 'يون', 'يول', 'أغس', 'سبت', 'أكت', 'نوف', 'ديس'];
    return names[(m - 1).clamp(0, 11)];
  }

  Future<void> _continueReading() async {
    final svc = context.read<QuranProgressService>();
    final pos = await svc.lastPosition();
    final s = pos?['surah'] ?? 1;
    final a = pos?['ayah'] ?? 1;
    if (!mounted) return;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => TanzilWebViewScreen(initialSurah: s, initialAyah: a),
    ));
  }
}
