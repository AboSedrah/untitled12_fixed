import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/settings_service.dart';
import 'tanzil_webview_screen.dart';

class QuranSurahListScreen extends StatefulWidget {
  const QuranSurahListScreen({super.key});

  @override
  State<QuranSurahListScreen> createState() => _QuranSurahListScreenState();
}

class _QuranSurahListScreenState extends State<QuranSurahListScreen> {
  int _surah = 1;
  final TextEditingController _ayahCtrl = TextEditingController(text: '1');

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsService>();
    return Scaffold(
      appBar: AppBar(title: const Text('القرآن الكريم (Tanzil)')),
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => FocusScope.of(context).unfocus(),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Text('السورة'),
                  const SizedBox(width: 12),
                  Expanded(
                    child: DropdownButton<int>(
                      isExpanded: true,
                      value: _surah,
                      items: List.generate(114, (i) => i + 1)
                          .map((n) => DropdownMenuItem(value: n, child: Text('$n')))
                          .toList(),
                      onChanged: (v) => setState(() => _surah = v ?? 1),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text('الآية'),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: _ayahCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(border: OutlineInputBorder(), hintText: '1'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                icon: const Icon(Icons.menu_book),
                label: const Text('فتح المصحف (Tanzil)'),
                onPressed: () {
                  final ayah = int.tryParse(_ayahCtrl.text.trim()) ?? 1;
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => TanzilWebViewScreen(initialSurah: _surah, initialAyah: ayah),
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => Navigator.of(context).pushNamed('/quran_stats'),
                      icon: const Icon(Icons.bar_chart),
                      label: const Text('إحصاءات القرآن'),
                    ),
                  ),
                ],
              ),
              const Spacer(),
              const Text('ملاحظة: العرض مباشرة من Tanzil لضمان تطابق الشكل.'),
            ],
          ),
        ),
      ),
    );
  }
}


