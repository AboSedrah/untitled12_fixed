import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:webview_flutter_wkwebview/webview_flutter_wkwebview.dart';
import '../../services/settings_service.dart';
import '../../services/quran_progress_service.dart';
import '../../services/juz_map.dart';

class TanzilWebViewScreen extends StatefulWidget {
  const TanzilWebViewScreen({super.key, required this.initialSurah, required this.initialAyah});
  final int initialSurah;
  final int initialAyah;

  @override
  State<TanzilWebViewScreen> createState() => _TanzilWebViewScreenState();
}

class _TanzilWebViewScreenState extends State<TanzilWebViewScreen> {
  late final WebViewController _controller;
  bool _loading = true;
  int _surah = 1;
  int _ayah = 1;
  int _currentJuz = 1;

  void _updateFromUrl(String? url) {
    if (url == null) return;
    try {
      final uri = Uri.parse(url);
      final hash = uri.fragment; // e.g., quran/2:5
      if (hash.isEmpty) return;
      final parts = hash.split('/');
      if (parts.length < 2) return;
      final sa = parts.last.split(':');
      final s = int.tryParse(sa[0]);
      final a = int.tryParse(sa.length > 1 ? sa[1] : '1');
      if (s != null && a != null && mounted) {
        setState(() {
          _surah = s;
          _ayah = a;
          _currentJuz = JuzMap.juzOf(_surah, _ayah);
        });
        final prog = context.read<QuranProgressService>();
        final settings = context.read<SettingsService>();
        prog.startDayIfNeeded(settings.quranDailyJuzCount);
        prog.updateLastPosition(_surah, _ayah);
      }
    } catch (_) {}
  }

  Future<void> _applyPageTweaks() async {
    const script = r"""
    (function() {
      try {
        const css = `
          * { -webkit-touch-callout: none !important; -webkit-user-select: none !important; user-select: none !important; }
          body { overscroll-behavior: none; }
        `;
        const s = document.createElement('style');
        s.type = 'text/css';
        s.appendChild(document.createTextNode(css));
        document.head.appendChild(s);

        const block = (e) => { try { e.preventDefault(); e.stopPropagation(); } catch(_) {} };
        ['contextmenu','selectstart','selectionchange','copy','cut'].forEach(evt => {
          document.addEventListener(evt, block, {passive:false, capture:true});
        });

        const post = () => { try { tanzil.postMessage(location.href); } catch (_) {} };
        window.addEventListener('hashchange', post);
        setTimeout(post, 100);
        setTimeout(post, 700);
      } catch (e) {}
    })();
    """;
    try { await _controller.runJavaScript(script); } catch (_) {}
  }

  @override
  void initState() {
    super.initState();
    final base = 'https://tanzil.net/';
    final hash = '#quran/${widget.initialSurah}:${widget.initialAyah}';
    _surah = widget.initialSurah; _ayah = widget.initialAyah; _currentJuz = JuzMap.juzOf(_surah, _ayah);

    final PlatformWebViewControllerCreationParams params;
    if (WebViewPlatform.instance is WebKitWebViewPlatform) {
      params = WebKitWebViewControllerCreationParams(
        allowsInlineMediaPlayback: true,
      );
    } else {
      params = const PlatformWebViewControllerCreationParams();
    }

    final controller = WebViewController.fromPlatformCreationParams(params)
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('tanzil', onMessageReceived: (msg) { _updateFromUrl(msg.message); })
      ..enableZoom(true)
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (req) => NavigationDecision.navigate,
        onUrlChange: (change) { _updateFromUrl(change.url); },
        onWebResourceError: (err) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('تعذر تحميل الصفحة: ${err.errorCode}')),
          );
        },
        onPageStarted: (_) { if (mounted) setState(() { _loading = true; }); },
        onPageFinished: (url) async {
          try { await _controller.runJavaScript("location.hash='$hash'"); } catch (_) {}
          await _applyPageTweaks();
          _updateFromUrl(url);
          if (!mounted) return;
          setState(() { _loading = false; });
        },
      ))
      ..setBackgroundColor(const Color(0xFFFFFFFF))
      ..setUserAgent('Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Mobile Safari/537.36');

    // ملاحظة: كاش الويب الافتراضي مفعّل ضمن WebView. لا حاجة لنداءات خاصة.

    _controller = controller..loadRequest(Uri.parse(base));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_loading)
            const Positioned(left: 0, right: 0, top: 0, child: LinearProgressIndicator()),
        ],
      ),
    );
  }
}


