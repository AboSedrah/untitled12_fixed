class Holiday {
  final String name;
  final DateTime date;

  Holiday({
    required this.name,
    required this.date,
  });
}