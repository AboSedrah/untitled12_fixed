import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF2563EB);
  static const secondary = Color(0xFF0EA5E9);
  static const surface = Color(0xFFF7F7FB);
  static const danger = Color(0xFFEF4444);
}

const arabicWeekdaysShort = [
  'أحد',
  'اثنين',
  'ثلثاء',
  'أربعاء',
  'خميس',
  'جمعة',
  'سبت'
];

const gregorianMonthsAr = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر'
];

const hijriMonthsAr = [
  'محرم',
  'صفر',
  'ربيع الأول',
  'ربيع الآخر',
  'جمادى الأولى',
  'جمادى الآخرة',
  'رجب',
  'شعبان',
  'رمضان',
  'شوال',
  'ذو القعدة',
  'ذو الحجة'
];

const openMeteoBase = 'https://api.open-meteo.com/v1/forecast';
const aladhanBase = 'https://api.aladhan.com/v1';
const nagerBase = 'https://date.nager.at/api/v3';