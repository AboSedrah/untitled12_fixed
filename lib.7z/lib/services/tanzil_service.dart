import 'package:shared_preferences/shared_preferences.dart';

class QuranPosition {
  final int surah;
  final int ayah;
  const QuranPosition(this.surah, this.ayah);
}

class TanzilService {
  static const String _kLastSurah = 'tanzil.last.surah';
  static const String _kLastAyah = 'tanzil.last.ayah';
  static const String _kLangKey = 'tanzil.ui.mode'; // 'quran' or 'trans/en.sahih'

  Future<void> saveLastPosition(int surah, int ayah) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(_kLastSurah, surah);
    await p.setInt(_kLastAyah, ayah);
  }

  Future<QuranPosition?> loadLastPosition() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getInt(_kLastSurah);
    final a = p.getInt(_kLastAyah);
    if (s != null && a != null) return QuranPosition(s, a);
    return null;
  }

  Future<void> setMode(String mode) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kLangKey, mode);
  }

  Future<String> getMode() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_kLangKey) ?? 'quran';
  }

  Future<String> buildUrl({required int surah, required int ayah}) async {
    final mode = await getMode();
    return 'https://tanzil.net/#$mode/$surah:$ayah';
  }
}



